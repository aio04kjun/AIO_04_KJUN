import inspect
import sys
import torch
import transformers
import tokenizers
from transformers.masking_utils import create_causal_mask

print("Python       :", sys.version.split()[0])
print("PyTorch      :", torch.__version__)
print("CUDA 사용    :", torch.cuda.is_available())
print("Transformers :", transformers.__version__)
print("Tokenizers   :", tokenizers.__version__)
print("create_causal_mask:", inspect.signature(create_causal_mask))

params = inspect.signature(create_causal_mask).parameters
if "input_embeds" not in params:
    raise RuntimeError(
        "현재 create_causal_mask에 input_embeds 인자가 없습니다. "
        "설치된 Transformers 버전을 확인하세요."
    )
if "cache_position" not in params:
    raise RuntimeError(
        "현재 create_causal_mask에 cache_position 인자가 없습니다."
    )

print("\n환경 검증 성공: EXAONE 원격 코드가 사용하는 mask 인자와 일치합니다.")
