$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectDir

Write-Host "=== EXAONE 3.5 2.4B CPU 환경 구성 ===" -ForegroundColor Cyan

# Python 3.12 확인
py -3.12 --version
if ($LASTEXITCODE -ne 0) {
    Write-Host "Python 3.12가 필요합니다. Python 3.12.x (64-bit)를 먼저 설치한 뒤 다시 실행하세요." -ForegroundColor Red
    exit 1
}

# 이 패키지 전용 가상환경만 새로 생성
if (Test-Path ".venv-exaone") {
    Remove-Item ".venv-exaone" -Recurse -Force
}

py -3.12 -m venv .venv-exaone
if ($LASTEXITCODE -ne 0) { throw "가상환경 생성 실패" }

& ".\.venv-exaone\Scripts\python.exe" -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip 업그레이드 실패" }

# PyTorch CPU 전용 설치
& ".\.venv-exaone\Scripts\python.exe" -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cpu
if ($LASTEXITCODE -ne 0) { throw "PyTorch CPU 설치 실패" }

# 나머지 라이브러리 고정 버전 설치
& ".\.venv-exaone\Scripts\python.exe" -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "기타 패키지 설치 실패" }

# 실제 설치 버전 및 create_causal_mask 인자 확인
& ".\.venv-exaone\Scripts\python.exe" verify_env.py
if ($LASTEXITCODE -ne 0) { throw "환경 검증 실패" }

# 공식 Hugging Face 모델 다운로드
& ".\.venv-exaone\Scripts\python.exe" download_model.py
if ($LASTEXITCODE -ne 0) { throw "모델 다운로드 실패" }

Write-Host ""
Write-Host "설치 완료!" -ForegroundColor Green
Write-Host "실행 명령:"
Write-Host "  .\.venv-exaone\Scripts\Activate.ps1"
Write-Host "  python main.py"
