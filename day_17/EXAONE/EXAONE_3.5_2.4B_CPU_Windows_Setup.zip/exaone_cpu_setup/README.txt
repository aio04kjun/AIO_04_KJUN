EXAONE 3.5 2.4B - Windows CPU 설치 패키지

필요 조건
- Windows 10/11 64-bit
- Python 3.12.x 64-bit 설치 및 Python Launcher(py) 사용 가능
- 모델 가중치 다운로드를 위한 인터넷 연결
- 충분한 RAM 권장: FP32 실행은 모델 가중치만 약 8.5GB 이상 메모리를 사용합니다.
  실제 실행에는 추가 메모리가 필요합니다.

설치 순서
1. ZIP 압축을 원하는 프로젝트 폴더에 풉니다.
2. Python 3.12.x 64-bit가 설치되어 있는지 확인합니다.
3. 압축을 푼 폴더에서 PowerShell을 엽니다.
4. 실행 정책 오류가 나면 현재 PowerShell 창에서 다음을 실행합니다.
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
5. 다음을 실행합니다.
   .\setup.ps1
6. 설치가 끝나면 다음을 실행합니다.
   .\.venv-exaone\Scripts\Activate.ps1
   python main.py

모델은 models\EXAONE-3.5-2.4B-Instruct 폴더에 다운로드됩니다.
재다운로드가 필요하면 가상환경을 활성화한 뒤 python download_model.py를 실행합니다.

고정 버전
- Python 3.12.x
- PyTorch 2.6.0 CPU
- Transformers 4.57.1
- Accelerate 1.11.0
- Hugging Face Hub 0.36.0
- Tokenizers 0.22.1
- Safetensors 0.6.2
- NumPy 1.26.4

중요
이 구성은 Transformers 5.x가 아닌 4.57.1을 사용합니다.
Transformers 4.57.1의 create_causal_mask는 input_embeds 및 cache_position 인자를 받으며,
사용자 환경의 Transformers 5.8.0에서 발생했던 input_embeds / inputs_embeds 인자명 불일치를
피하기 위한 고정 구성입니다.
