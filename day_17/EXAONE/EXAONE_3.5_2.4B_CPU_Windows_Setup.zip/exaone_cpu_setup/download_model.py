from pathlib import Path
from huggingface_hub import snapshot_download

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models" / "EXAONE-3.5-2.4B-Instruct"
REPO_ID = "LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct"

MODEL_DIR.mkdir(parents=True, exist_ok=True)

print(f"모델 다운로드 시작: {REPO_ID}")
print(f"저장 위치: {MODEL_DIR}")

snapshot_download(
    repo_id=REPO_ID,
    local_dir=str(MODEL_DIR),
)

print("모델 다운로드 완료")
