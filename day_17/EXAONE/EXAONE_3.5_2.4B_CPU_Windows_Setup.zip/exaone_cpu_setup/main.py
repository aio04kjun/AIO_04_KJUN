import time
import traceback
from pathlib import Path

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models" / "EXAONE-3.5-2.4B-Instruct"

DEVICE = torch.device("cpu")
MAX_NEW_TOKENS = 64

# CPU 스레드 수: PC의 물리 코어 수에 맞게 4~8 정도로 조정 가능
torch.set_num_threads(4)

def load_model():
    if not MODEL_DIR.exists() or not (MODEL_DIR / "config.json").exists():
        raise FileNotFoundError(
            f"모델 폴더를 찾을 수 없습니다: {MODEL_DIR}\n"
            "먼저 python download_model.py를 실행하세요."
        )

    print("토크나이저 로딩 중...")
    tokenizer = AutoTokenizer.from_pretrained(
        str(MODEL_DIR),
        trust_remote_code=True,
        local_files_only=True,
    )

    print("모델 로딩 중... CPU에서는 시간이 걸릴 수 있습니다.")
    model = AutoModelForCausalLM.from_pretrained(
        str(MODEL_DIR),
        torch_dtype=torch.float32,
        trust_remote_code=True,
        low_cpu_mem_usage=True,
        local_files_only=True,
    )
    model.to(DEVICE)
    model.eval()

    print("모델 로딩 완료")
    print("모델 dtype:", next(model.parameters()).dtype)
    print("모델 device:", next(model.parameters()).device)
    return tokenizer, model

def chat(tokenizer, model, question):
    messages = [
        {
            "role": "system",
            "content": "당신은 한국어로 정확하고 이해하기 쉽게 답변하는 AI assistant입니다."
        },
        {"role": "user", "content": question},
    ]

    input_ids = tokenizer.apply_chat_template(
        messages,
        tokenize=True,
        add_generation_prompt=True,
        return_tensors="pt",
    ).to(DEVICE)

    print(f"입력 토큰 길이: {input_ids.shape[-1]}")
    print("답변 생성 중...")

    start = time.perf_counter()
    with torch.inference_mode():
        output_ids = model.generate(
            input_ids=input_ids,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            use_cache=True,
            pad_token_id=tokenizer.eos_token_id,
        )

    elapsed = time.perf_counter() - start
    new_tokens = output_ids[0, input_ids.shape[-1]:]
    answer = tokenizer.decode(new_tokens, skip_special_tokens=True)

    print("\n답변:")
    print(answer.strip())
    print(f"\n생성 시간: {elapsed:.2f}초")
    print(f"생성 토큰 수: {len(new_tokens)}")
    if elapsed > 0:
        print(f"속도: {len(new_tokens) / elapsed:.2f} tokens/sec")

def main():
    tokenizer, model = load_model()

    while True:
        question = input("\n질문 (종료: q): ").strip()
        if question.lower() in {"q", "quit", "exit"}:
            break
        if not question:
            continue

        try:
            chat(tokenizer, model, question)
        except Exception:
            traceback.print_exc()

if __name__ == "__main__":
    main()
